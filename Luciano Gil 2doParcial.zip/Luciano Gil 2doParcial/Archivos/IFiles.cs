﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Archivos
{
    public interface IFiles<T>
    {
        bool Leer(string RutaArchivo, out T objeto);
        bool Leer(string RutaArchivom, out T objeto, Encoding encoding);

        void Guardar(string RutaArchivo, T objeto);
        void Guardar(string RutaArchivo, T objeto, Encoding encoding);


    }
}
