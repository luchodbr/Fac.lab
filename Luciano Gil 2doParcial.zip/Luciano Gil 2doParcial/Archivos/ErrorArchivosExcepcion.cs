﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Archivos
{
    public class ErrorArchivosExcepcion : Exception
    {
        public ErrorArchivosExcepcion() : base("Error del tipo Archivo Exception")
        {

        }
        public ErrorArchivosExcepcion(string s) : this(s, null)
        {

        }
        public ErrorArchivosExcepcion(string s, Exception e) : base(s, e)
        {

        }
    }
}
