﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;
namespace Archivos
{
    public class Xml<T> : IFiles<T> 
    {
 

        public string GetDirectoryPath
        {
            get { return AppDomain.CurrentDomain.BaseDirectory+"\\"; }

        }
        public bool FileExists(string NombreArchivo)
        {
            return FileExists(GetDirectoryPath+NombreArchivo);
        }

        public void Guardar(string NombreArchivo, T objeto)
        {
            Guardar(NombreArchivo, objeto, System.Text.Encoding.UTF8);
        }
        public void Guardar(string NombreArchivo, T objeto, Encoding encoding)
        {

                string RutaArchivo = GetDirectoryPath + NombreArchivo;
                XmlTextWriter Escritor = new XmlTextWriter(RutaArchivo, System.Text.Encoding.UTF8);
            XmlSerializer ser = new XmlSerializer((typeof(T)));
            try
            {
                
                ser.Serialize(Escritor, objeto);


            }
            catch (Exception e)
            {

                throw new ErrorArchivosExcepcion("error al guardar",e);
            }
            finally
              {
                Escritor.Close();
                
            }
               

        }
        public bool Leer(string nombreArchivo, out T objeto)
        {
           return Leer(nombreArchivo, out objeto, System.Text.Encoding.UTF8);
        
        }
        public bool Leer(string nombreArchivo, out T objeto, Encoding encoding)
        {
            string RutaArchivo = AppDomain.CurrentDomain.BaseDirectory + nombreArchivo;
            XmlTextReader reader = new XmlTextReader(RutaArchivo);
            XmlSerializer ser = new XmlSerializer(typeof(T));
            object aux = new object();
            try
            {
                aux = (T)ser.Deserialize(reader);
                objeto = (T)aux;
                return true;
            }
            catch (Exception e)
            {
                objeto = (T)aux;
                return false;
                throw new ErrorArchivosExcepcion("error al leer",e);
            }
            finally
            {
                reader.Close();

            }
        }

    }
}
