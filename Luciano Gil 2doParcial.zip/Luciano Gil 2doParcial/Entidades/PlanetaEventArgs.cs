﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class PlanetaEventArgs:EventArgs
    {
        public PlanetaEventArgs(short av,short rad)
        {
            this.avance = av;
            this.radioRespectoSol = rad;
        }
        private short avance;
        public short Avance
        {
            get { return avance; }
            set { avance = value; }
        }
        private short radioRespectoSol;
        public short RadioRespectoSol
        {
            get { return radioRespectoSol; }
            set { radioRespectoSol = value; }
        }


 
    }
}
